import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/layout/Header';
import EventsPage from './pages/EventsPage';
import EventDetailPage from './pages/EventDetailPage';
import AssistantPage from './pages/AssistantPage';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Header />
        <main>
          <Routes>
            <Route path="/" element={<EventsPage />} />
            <Route path="/events" element={<EventsPage />} />
            <Route path="/events/:id" element={<EventDetailPage />} />
          </Routes>
        </main>
        <AssistantPage />
      </div>
    </Router>
  );
}

export default App;