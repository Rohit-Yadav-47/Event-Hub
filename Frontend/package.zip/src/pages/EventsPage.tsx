import React, { useState, useEffect } from 'react';
import EventGrid from '../components/events/EventGrid';
import EventFiltersPanel from '../components/events/EventFilters';
import { EventFilters } from '../types';
import AssistantPage from './AssistantPage'; // Import AssistantPage
import axios from 'axios';

const API_URL = 'http://127.0.0.1:8000/events'; // Replace with your actual API endpoint

const EventsPage = () => {
  const [events, setEvents] = useState([]);
  const [filters, setFilters] = useState<EventFilters>({});
  const [isLoading, setIsLoading] = useState(true); 
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchEvents = async () => {
      setIsLoading(true);
      try {
        const response = await axios.get(API_URL, { params: filters });
        setEvents(response.data); 
      } catch (error) {
        setError(error.message);
      } finally {
        setIsLoading(false); 
      }
    };

    fetchEvents();
  }, [filters]);

  const handleFilterChange = (updatedFilters: EventFilters) => {
    setFilters(updatedFilters);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        <div className="md:w-1/4">
          <EventFiltersPanel filters={filters} onFilterChange={handleFilterChange} />
        </div>
        <div className="md:w-3/4">
          <h1 className="text-3xl font-bold mb-6">Discover Events</h1>
          {isLoading ? (
            <p>Loading events...</p>
          ) : error ? (
            <p className="text-red-500">Error: {error}</p>
          ) : (
            <EventGrid events={events} /> 
          )}
        </div>
      </div>
      <AssistantPage /> {/* Add AssistantPage component */}
    </div>
  );
};

export default EventsPage;