import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Search, MessageSquare, Menu } from 'lucide-react';

export default function Header() {
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center gap-2">
            <Calendar className="w-6 h-6 text-blue-600" />
            <span className="font-bold text-xl">EventHub</span>
          </Link>

          <nav className="hidden md:flex items-center gap-6">
            <Link to="/events" className="text-gray-700 hover:text-blue-600">Events</Link>
            
          </nav>

          <div className="flex items-center gap-4">
            <Link to="/search" className="p-2 text-gray-700 hover:text-blue-600">
              <Search className="w-5 h-5" />
            </Link>
            <Link to="/assistant" className="p-2 text-gray-700 hover:text-blue-600">
              <MessageSquare className="w-5 h-5" />
            </Link>
            <button className="md:hidden p-2">
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}