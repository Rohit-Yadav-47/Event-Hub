import React from 'react';
import { Message } from '../../types';
import { Bot, User, Calendar, Clock, MapPin, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';

interface ChatMessageProps {
  message: Message;
}

export default function ChatMessage({ message }: ChatMessageProps) {
  const isBot = message.sender === 'bot';

  const parseContent = (content: string) => {
    const lines = content.split('\n');
    const intro = lines[0];
    const outro = lines[lines.length - 1];
    return { intro, outro };
  };

  const renderEventCard = (event: any) => (
    <Link 
      to={`/events/${event.id}`}
      className="block bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow"
    >
      <div className="flex flex-col h-full">
        <h3 className="font-semibold text-lg text-gray-900">{event.name}</h3>
        <p className="text-gray-600 text-sm mt-1 flex-grow">{event.description}</p>
        
        <div className="mt-3 space-y-2 border-t pt-3">
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <MapPin className="w-4 h-4 text-blue-600" />
            <span>{event.location}</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Calendar className="w-4 h-4 text-blue-600" />
            <span>{event.date}</span>
            <Clock className="w-4 h-4 ml-2 text-blue-600" />
            <span>{event.time}</span>
          </div>
        </div>
      </div>
    </Link>
  );

  if (!isBot) {
    return (
      <div className="flex gap-3 justify-end mb-4">
        <div className="max-w-[90%] bg-blue-600 text-white rounded-lg p-4 shadow-sm">
          <p className="text-sm whitespace-pre-wrap">{message.content}</p>
        </div>
        <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center">
          <User className="w-5 h-5 text-white" />
        </div>
      </div>
    );
  }

  const { intro, outro } = parseContent(message.content);

  return (
    <div className="flex gap-3 justify-start mb-4">
      <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
        <Bot className="w-5 h-5 text-blue-600" />
      </div>
      <div className="max-w-[90%] space-y-4">
        {intro && (
          <p className="text-sm text-gray-800 font-medium">{intro}</p>
        )}
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {message.events && message.events.map((event, index) => (
            <div key={event.id || index}>
              {renderEventCard(event)}
            </div>
          ))}
        </div>

        {outro && outro !== intro && (
          <p className="text-sm text-gray-600">{outro}</p>
        )}
      </div>
    </div>
  );
}