import { ChatFilters } from '../types';
import axios from 'axios';

const API_URL = 'http://127.0.0.1:8000';

export const getChatResponse = async (content: string, filters: any) => {
  const url = `${API_URL}/chatbot`;
  const data = {
    query: content,
    location: filters?.location || '',
    event_type: filters?.event_type || ''
  };

  const response = await axios.post(url, data);
  return {
    response: response.data.response,
    events: response.data.events
  };
};